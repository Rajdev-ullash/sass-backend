// Define your constants here

export const zoneFilterableFields: string[] = ['searchTerm', 'id'];

export const zoneSearchableFields: string[] = ['title'];
