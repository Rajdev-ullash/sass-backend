// Define your interfaces here
export type IZoneFilterRequest = {
  searchTerm?: string | undefined;
};
