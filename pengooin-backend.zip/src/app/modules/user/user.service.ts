import { Buyer, User } from '@prisma/client';
import bcrypt from 'bcrypt';
import httpStatus from 'http-status';
import config from '../../../config';
import ApiError from '../../../errors/ApiError';
import prisma from '../../../shared/prisma';

// Your service code here
const createBuyer = async (buyer: Buyer, user: User): Promise<User | null> => {
  // set role
  user.role = 'buyer';

  const isEmailExist = await prisma.buyer.findFirst({
    where: {
      email: buyer.email,
    },
  });

  if (isEmailExist) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'This email already exists');
  }

  const isUserNameExist = await prisma.buyer.findFirst({
    where: {
      username: buyer.username,
    },
  });

  if (isUserNameExist) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'This username already exists');
  }

  const hashedPassword = await bcrypt.hash(
    user.password,
    Number(config.bycrypt_salt_rounds)
  );

  const data = await prisma.$transaction(async transactionClient => {
    const buyers = await transactionClient.buyer.create({
      data: {
        email: buyer.email,
        username: buyer.username,
        zoneId: buyer.zoneId,
        address: buyer.address,
        mobileNumber: buyer.mobileNumber,
      },
    });

    const createNewUser = await transactionClient.user.create({
      data: {
        role: user.role,
        password: hashedPassword,
        buyerId: buyers.id,
      },
      include: {
        buyer: true,
      },
    });

    if (!createNewUser) {
      throw new ApiError(httpStatus.BAD_REQUEST, 'Failed to create user');
    }
    return createNewUser;
  });
  return data;
};

export const UserService = {
  createBuyer,
};
