// Define your constants here

export const brandFilterableFields: string[] = ['searchTerm', 'id'];

export const brandSearchableFields: string[] = ['title'];
