// Define your interfaces here
export type IBrandFilterRequest = {
  searchTerm?: string | undefined;
};
