// Define your constants here
export const categoryFilterableFields: string[] = ['searchTerm', 'id', 'title'];

export const categorySearchableFields: string[] = ['title'];
