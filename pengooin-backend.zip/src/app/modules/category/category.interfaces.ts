// Define your interfaces here
export type ICategoryFilterRequest = {
  searchTerm?: string | undefined;
};
