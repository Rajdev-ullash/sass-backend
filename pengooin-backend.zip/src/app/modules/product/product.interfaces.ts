// Define your interfaces here
export type IProductFilterRequest = {
  searchTerm?: string | undefined;
  minPrice?: number | undefined;
  maxPrice?: number | undefined;
  buildingId?: string | undefined;
};

export type ProductInput = {
  title: string;
  slug: string;
  description: string;
  price: number;
  categoryId?: string;
  stock: number;
  unit: string;
  sell: number;
  productImages: CloudinaryUploadFile[]; // Assuming you have a CloudinaryUploadFile interface
};

export type CloudinaryUploadFile = {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  buffer: Buffer;
  size: number;
  public_id?: string; // Add this line to include public_id property
};
