// Define your interfaces here
