import express from 'express';
import { AuthRoutes } from '../modules/auth/auth.routes';
import { brandRoutes } from '../modules/brand/brand.routes';
import { categoryRoutes } from '../modules/category/category.routes';
import { productRoutes } from '../modules/product/product.routes';
import { UserRoutes } from '../modules/user/user.routes';
import { zoneRoutes } from '../modules/zone/zone.routes';

const router = express.Router();

const moduleRoutes = [
  // ... routes
  {
    path: '/users',
    route: UserRoutes,
  },
  {
    path: '/auth',
    route: AuthRoutes,
  },
  {
    path: '/zones',
    route: zoneRoutes,
  },
  {
    path: '/categories',
    route: categoryRoutes,
  },
  {
    path: '/brands',
    route: brandRoutes,
  },
  {
    path: '/products',
    route: productRoutes,
  },
];

moduleRoutes.forEach(route => router.use(route.path, route.route));
export default router;
