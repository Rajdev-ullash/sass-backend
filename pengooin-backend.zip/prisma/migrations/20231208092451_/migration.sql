-- AlterTable
ALTER TABLE "buyers" ALTER COLUMN "mobileNumber" SET DATA TYPE TEXT;
