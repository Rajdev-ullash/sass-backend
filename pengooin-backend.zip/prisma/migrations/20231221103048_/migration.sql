-- AlterTable
ALTER TABLE "products" ALTER COLUMN "sell" SET DEFAULT 0;
